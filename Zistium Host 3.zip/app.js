/* زیستیوم — منطق اپلیکیشن (نسخه حرفه‌ای) */
'use strict';

const KEY = 'zistium_demo_v1';
const SESSION_KEY = 'zistium_supabase_session_v1';
const SUPABASE_URL = 'https://mnlhuegrpazicrnllqkq.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_UpMI2igYbqYLGnNefyr9EQ_0pNRyTXH';

const sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: { persistSession: true, autoRefreshToken: true }
});

let state = { exams: [], results: [] };
let role = 'student';
let user = { id: '', name: '', email: '', role: 'student' };
let page = 'dashboard';
let activeExam = null, examAnswers = {}, examTimer = null;
let authMode = 'login';
let lbChannel = null, lbTimer = null, lbExamFilter = 'all';

/* ---------- ابزارها ---------- */
const faNum = n => String(n).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
function esc(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

const I = {
  flask:'<path d="M10 2v6L4.5 18a2 2 0 0 0 1.8 3h11.4a2 2 0 0 0 1.8-3L14 8V2"/><path d="M7.5 2h9"/><path d="M7 14h10"/>',
  target:'<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
  trophy:'<path d="M8 21h8"/><path d="M12 17v4"/><path d="M7 4h10v5a5 5 0 0 1-10 0z"/><path d="M7 6H4a2 2 0 0 0 2 4h1"/><path d="M17 6h3a2 2 0 0 1-2 4h-1"/>',
  chart:'<path d="M3 3v18h18"/><path d="M7 15l4-5 3 3 5-7"/>',
  check:'<path d="M20 6L9 17l-5-5"/>',
  trend:'<path d="M23 6l-9.5 9.5-5-5L1 18"/><path d="M17 6h6v6"/>',
  clock:'<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
  home:'<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 22V12h6v10"/>',
  plus:'<path d="M12 5v14"/><path d="M5 12h14"/>',
  grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  users:'<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  leaf:'<path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10z"/><path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"/>',
  book:'<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
  spark:'<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/><path d="M19 17l.9 2.1L22 20l-2.1.9L19 23l-.9-2.1L16 20l2.1-.9z"/>'
};
function ic(name, cls = '') { return `<svg class="icon ${cls}" viewBox="0 0 24 24" aria-hidden="true">${I[name] || I.spark}</svg>`; }

function toast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove('show'), 3000);
}
function loadState() { try { return JSON.parse(localStorage.getItem(KEY)) || { exams: [], results: [] }; } catch { return { exams: [], results: [] }; } }
function saveState() { try { localStorage.setItem(KEY, JSON.stringify(state)); } catch {} }
function showErr(msg) { const el = document.getElementById('loginError'); el.textContent = msg; el.hidden = false; }
function hideErr() { document.getElementById('loginError').hidden = true; }

/* ---------- احراز هویت ---------- */
function setAuthMode(mode) { authMode = mode; hideErr(); hideSignupErr(); }

function showLogin() {
  document.getElementById('signupScreen').hidden = true;
  document.getElementById('loginScreen').hidden = false;
  authMode = 'login'; hideErr(); hideSignupErr();
}
function showSignup() {
  document.getElementById('loginScreen').hidden = true;
  document.getElementById('signupScreen').hidden = false;
  authMode = 'signup'; hideErr(); hideSignupErr();
  setTimeout(() => document.getElementById('signupName').focus(), 50);
}
function showSignupErr(msg) { const el = document.getElementById('signupError'); el.textContent = msg; el.hidden = false; }
function hideSignupErr() { const el = document.getElementById('signupError'); if (el) { el.textContent = ''; el.hidden = true; } }
function setRole(r) {
  role = r;
  document.getElementById('studentRole').classList.toggle('active', r === 'student');
  document.getElementById('teacherRole').classList.toggle('active', r === 'teacher');
  if (r === 'teacher' && authMode === 'signup') setAuthMode('login');
  hideErr();
}

document.getElementById('loginForm').addEventListener('submit', async e => {
  e.preventDefault(); hideErr();
  const name = '';
  const email = document.getElementById('loginEmail').value.trim().toLowerCase();
  const password = document.getElementById('loginPassword').value;
  const btn = document.getElementById('loginSubmit');
  if (!email || !password) { showErr('ایمیل و رمز عبور را وارد کن.'); return; }
  btn.disabled = true;
  try {
    {
      const { data, error } = await sb.auth.signInWithPassword({ email, password });
      if (error) {
        const m = (error.message || '').toLowerCase();
        if (m.includes('invalid login')) showErr('ایمیل یا رمز عبور اشتباه است؛ یا هنوز حساب نساخته‌ای. از دکمه «ثبت‌نام کن» حساب بساز.');
        else if (m.includes('not confirmed')) showErr('ایمیلت تأیید نشده. اول لینک تأیید که به ایمیلت آمده را باز کن.');
        else if (m.includes('rate limit')) showErr('چند بار تلاش کردی؛ یک دقیقه صبر کن و دوباره امتحان کن.');
        else showErr('خطای ورود: ' + error.message);
        return;
      }
      let account = { id: data.user.id, name: data.user.user_metadata?.username || name || email.split('@')[0], email, role: 'student' };
      const { data: profile } = await sb.from('profiles').select('username,role').eq('id', data.user.id).maybeSingle();
      if (profile) { account.name = profile.username || account.name; account.role = profile.role || 'student'; }
      if (role === 'teacher' && account.role !== 'teacher') { await sb.auth.signOut(); showErr('این حساب دسترسی معلم ندارد.'); return; }
      localStorage.setItem(SESSION_KEY, JSON.stringify(account));
      enterApp(account);
    }
  } finally { btn.disabled = false; }
});

/* ---------- ثبت‌نام ---------- */
document.getElementById('signupForm').addEventListener('submit', async e => {
  e.preventDefault(); hideSignupErr();
  const name = document.getElementById('signupName').value.trim();
  const email = document.getElementById('signupEmail').value.trim().toLowerCase();
  const password = document.getElementById('signupPassword').value;
  const btn = document.getElementById('signupSubmit');
  if (!name) { showSignupErr('نام نمایشی را وارد کن.'); return; }
  if (!email) { showSignupErr('ایمیل را وارد کن.'); return; }
  if (password.length < 6) { showSignupErr('رمز عبور باید حداقل ۶ کاراکتر باشد.'); return; }
  btn.disabled = true;
  try {
    const { data, error } = await sb.auth.signUp({ email, password, options: { data: { username: name } } });
    if (error) {
      const m = (error.message || '').toLowerCase();
      if (m.includes('already registered')) showSignupErr('این ایمیل قبلاً ثبت شده. برگرد و وارد شو.');
      else if (m.includes('invalid')) showSignupErr('این ایمیل معتبر شناخته نشد. یک ایمیل واقعی وارد کن (مثلاً جیمیل یا اوت‌لوک).');
      else if (m.includes('rate limit')) showSignupErr('چند بار تلاش کردی؛ یک دقیقه صبر کن.');
      else if (m.includes('password')) showSignupErr('رمز عبور باید حداقل ۶ کاراکتر باشد.');
      else showSignupErr('خطای ثبت‌نام: ' + error.message);
      return;
    }
    if (!data.session) {
      toast('حساب ساخته شد؛ ایمیلت را تأیید کن و سپس وارد شو.');
      document.getElementById('signupForm').reset();
      showLogin();
      return;
    }
    const account = { id: data.user.id, name, email, role: 'student' };
    localStorage.setItem(SESSION_KEY, JSON.stringify(account));
    toast('حساب در Supabase ساخته شد.');
    enterApp(account);
  } finally { btn.disabled = false; }
});

async function logout() {
  stopLeaderboardLive();
  if (examTimer) clearInterval(examTimer);
  await sb.auth.signOut();
  localStorage.removeItem(SESSION_KEY);
  document.getElementById('app').hidden = true;
  document.body.classList.remove('app-ready');
  closeChatbot();
  document.getElementById('signupScreen').style.display = '';
  document.getElementById('loginScreen').style.display = 'grid';
  document.getElementById('loginForm').reset();
  const sf = document.getElementById('signupForm'); if (sf) sf.reset();
  setAuthMode('login'); activeExam = null;
}

(async () => {
  const { data: { session } } = await sb.auth.getSession();
  if (!session) return;
  let account = { id: session.user.id, name: session.user.user_metadata?.username || session.user.email?.split('@')[0] || 'دانش‌آموز', email: session.user.email, role: 'student' };
  const { data: profile } = await sb.from('profiles').select('username,role').eq('id', session.user.id).maybeSingle();
  if (profile) { account.name = profile.username || account.name; account.role = profile.role || 'student'; }
  enterApp(account);
})();

sb.auth.onAuthStateChange((event) => { if (event === 'SIGNED_OUT') logout(); });

/* ---------- ورود به اپ ---------- */
function enterApp(account) {
  user = { id: account.id || '', name: account.name, email: account.email, role: account.role || 'student' };
  role = user.role;
  document.getElementById('loginScreen').style.display = 'none';
  document.getElementById('signupScreen').style.display = 'none';
  document.getElementById('app').hidden = false;
  document.getElementById('userName').textContent = user.name;
  document.getElementById('userRoleLabel').textContent = user.role === 'teacher' ? 'پنل معلم' : 'پنل دانش‌آموز';
  document.getElementById('avatar').textContent = (user.name[0] || 'ز').toUpperCase();
  document.body.classList.add('app-ready');
  renderNav(); go('dashboard');
  refreshData().then(() => { if (page === 'dashboard') renderDashboard(); });
}

async function refreshData() {
  await Promise.all([loadExamsFromDatabase(), loadResultsFromDatabase()]);
}

/* ---------- بارگذاری داده‌ها (بهینه: بدون کوئری تودرتو) ---------- */
async function loadExamsFromDatabase() {
  const { data: rows, error } = await sb.from('zistium_exams')
    .select('id,title,exam_date,duration,description,status,created_by')
    .order('created_at', { ascending: false });
  if (error) { toast('خطای دریافت آزمون‌ها: ' + error.message); return; }

  const { data: qs, error: qerr } = await sb.from('zistium_questions')
    .select('id,exam_id,question_text,options,position')
    .order('position');
  if (qerr) { toast('خطای دریافت سؤال‌ها: ' + qerr.message); return; }

  // کلیدها فقط برای معلم قابل خواندن هستند
  const keyMap = {};
  if (user.role === 'teacher' && qs?.length) {
    const { data: keys } = await sb.from('zistium_answer_keys').select('question_id,correct_answer');
    (keys || []).forEach(k => { keyMap[k.question_id] = k.correct_answer; });
  }

  const byExam = {};
  (qs || []).forEach(q => { (byExam[q.exam_id] = byExam[q.exam_id] || []).push(q); });

  state.exams = (rows || []).map(r => ({
    id: r.id, title: r.title, date: r.exam_date || '', duration: r.duration || 15,
    desc: r.description || '', status: r.status || 'آماده',
    questions: (byExam[r.id] || []).map(q => ({
      id: q.id, text: q.question_text,
      options: Array.isArray(q.options) ? q.options : [],
      correct: keyMap[q.id] ?? 0
    }))
  }));
  saveState();
}

async function loadResultsFromDatabase() {
  const { data: rows, error } = await sb.from('zistium_attempts')
    .select('id,exam_id,student_id,score,correct_count,total_questions,created_at,profiles(username),zistium_exams(title)')
    .order('created_at', { ascending: false });
  if (error) { console.warn('دریافت نتایج:', error.message); return; }
  state.results = (rows || []).map(r => ({
    id: r.id, examId: r.exam_id,
    title: r.zistium_exams?.title || 'آزمون',
    studentId: r.student_id,
    student: r.profiles?.username || (r.student_id === user.id ? user.name : 'دانش‌آموز'),
    score: r.score, correctCount: r.correct_count, totalQuestions: r.total_questions,
    dateTaken: new Date(r.created_at).toLocaleDateString('fa-IR'),
    createdAt: r.created_at
  }));
  saveState();
}

/* ---------- ناوبری ---------- */
function toggleMenu() {
  const sb2 = document.getElementById('sidebar'), ov = document.getElementById('overlay');
  const open = sb2.classList.toggle('open');
  ov.classList.toggle('show', open);
}
function renderNav() {
  const items = user.role === 'teacher'
    ? [['dashboard', 'home', 'داشبورد'], ['create', 'plus', 'ثبت آزمون جدید'], ['questions', 'grid', 'مدیریت آزمون‌ها'], ['students', 'users', 'نتایج دانش‌آموزان'], ['leaderboard', 'trophy', 'جدول رتبه‌بندی']]
    : [['dashboard', 'home', 'داشبورد'], ['exams', 'book', 'آزمون‌های من'], ['progress', 'trend', 'نمودار پیشرفت'], ['results', 'check', 'نمرات من'], ['leaderboard', 'trophy', 'جدول رتبه‌بندی'], ['counselor', 'users', 'مشاور رسمی']];
  document.getElementById('nav').innerHTML = items
    .map(a => `<button type="button" data-page="${a[0]}" onclick="go('${a[0]}')"><span>${ic(a[1])}</span>${a[2]}</button>`).join('');
}
function go(p) {
  if (page !== 'leaderboard' && p !== 'leaderboard') {} // noop
  page = p;
  document.querySelectorAll('.nav button').forEach(b => b.classList.toggle('active', b.dataset.page === p));
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('overlay').classList.remove('show');
  const titles = { dashboard: 'داشبورد', create: 'ثبت آزمون جدید', questions: 'مدیریت آزمون‌ها', students: 'نتایج دانش‌آموزان', exams: 'آزمون‌های من', progress: 'نمودار پیشرفت', results: 'نمرات من', take: 'آزمون در حال برگزاری', leaderboard: 'جدول رتبه‌بندی زنده', counselor: 'مشاور رسمی' };
  document.getElementById('pageTitle').textContent = titles[p] || 'زیستیوم';
  document.getElementById('eyebrow').textContent = user.role === 'teacher' ? 'فضای مدیریت معلم' : 'فضای یادگیری شما';
  const renderers = { dashboard: renderDashboard, create: renderCreate, questions: renderManage, students: renderStudents, exams: renderExams, progress: renderProgress, results: renderResults, take: renderTake, leaderboard: renderLeaderboard, counselor: renderCounselor };
  (renderers[p] || renderDashboard)();
  window.scrollTo({ top: 0, behavior: 'instant' in window ? 'instant' : 'auto' });
}

/* ---------- اجزای مشترک ---------- */
function stat(icon, cls, label, value, unit = '') {
  return `<div class="stat"><div class="stat-icon ${cls}">${ic(icon)}</div><div><div class="stat-label">${label}</div><div class="stat-value">${value}<small> ${unit}</small></div></div></div>`;
}
function panel(title, body, extra = '') {
  return `<section class="panel"><div class="panel-head"><h2>${title}</h2>${extra}</div>${body}</section>`;
}
function getMyResults() {
  return state.results.filter(r => r.studentId ? r.studentId === user.id : r.student === user.name);
}
function average(arr) { return arr.length ? Math.round(arr.reduce((a, b) => a + b.score, 0) / arr.length) : 0; }

function chartSvg(values) {
  if (!values.length) return '';
  const max = 100;
  const step = 340 / Math.max(values.length - 1, 1);
  const pts = values.map((v, i) => `${30 + i * step},${185 - (v / max) * 155}`).join(' ');
  const area = `30,185 ${pts} ${30 + (values.length - 1) * step},185`;
  return `<div class="chart-wrap"><svg viewBox="0 0 400 205" role="img" aria-label="نمودار نمرات">
    <defs><linearGradient id="area" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="#2dd4a7" stop-opacity=".25"/><stop offset="100%" stop-color="#2dd4a7" stop-opacity="0"/></linearGradient></defs>
    ${[30, 70, 110, 150, 185].map(y => `<line x1="25" y1="${y}" x2="385" y2="${y}" stroke="#1a2740" stroke-dasharray="3 4"/>`).join('')}
    <polygon points="${area}" fill="url(#area)"/>
    <polyline points="${pts}" fill="none" stroke="#2dd4a7" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
    ${values.map((v, i) => `<circle cx="${30 + i * step}" cy="${185 - (v / max) * 155}" r="4" fill="#0a111e" stroke="#2dd4a7" stroke-width="2"/>`).join('')}
  </svg><div class="chart-labels">${values.map((_, i) => `<span>${faNum(i + 1)}</span>`).join('')}</div></div>`;
}

function examRow(exam, actionText, action, tag = 'در انتظار') {
  return `<div class="exam-row"><div class="exam-icon">${ic("flask")}</div><div class="exam-info"><strong>${esc(exam.title)}</strong><small>${ic("clock")} ${esc(exam.date || 'بدون تاریخ')} &nbsp;·&nbsp; ${faNum(exam.questions?.length || 0)} سؤال &nbsp;·&nbsp; ${faNum(exam.duration || 15)} دقیقه</small></div><span class="badge ${tag === 'برگزار شده' ? 'done' : ''}">${tag}</span><button type="button" class="btn btn-purple" onclick="${action}('${exam.id}')">${actionText}</button></div>`;
}
function examList(exams) {
  return exams.length
    ? `<div class="exam-list">${exams.map(e => `<div class="exam-row"><div class="exam-icon">${ic("flask")}</div><div class="exam-info"><strong>${esc(e.title)}</strong><small>${esc(e.date || 'بدون تاریخ')} · ${faNum(e.questions?.length || 0)} سؤال</small></div><span class="badge">${esc(e.status || 'آماده')}</span></div>`).join('')}</div>`
    : `<div class="empty">هنوز آزمونی ثبت نشده است.</div>`;
}

/* ---------- داشبورد ---------- */
function renderDashboard() {
  if (user.role === 'teacher') {
    const done = state.results.length, upcoming = state.exams.length;
    document.getElementById('content').innerHTML = `
      <div class="notice">${ic("leaf")} سلام ${esc(user.name)}! از اینجا می‌تونی آزمون جدید بسازی، سؤال اضافه کنی و نتایج دانش‌آموزها رو ببینی.</div>
      <div class="grid stats">
        ${stat('users', 'purple', 'پاسخ‌های ثبت‌شده', faNum(done), 'پاسخ')}
        ${stat('book', 'green', 'آزمون‌های ساخته‌شده', faNum(upcoming), 'آزمون')}
        ${stat('trophy', 'blue', 'میانگین نمرات', done ? faNum(average(state.results)) : '—', done ? 'از ۱۰۰' : '')}
        ${stat('trend', 'orange', 'بالاترین نمره کلاس', done ? faNum(Math.max(...state.results.map(r => r.score))) : '—', done ? 'از ۱۰۰' : '')}
      </div>
      <div class="grid two-col">
        ${panel('آخرین آزمون‌ها', examList(state.exams.slice(0, 4)), `<button type="button" class="link-btn" onclick="go('questions')">مشاهده همه ←</button>`)}
        ${panel('شروع سریع', `<p style="font-size:13px;color:var(--muted);line-height:2">یک آزمون جدید برای کلاس طراحی کن و با چند سؤال، میزان یادگیری را بسنج.</p>
          <button type="button" class="btn btn-primary full" onclick="go('create')">${ic('plus')} ساخت آزمون جدید</button>
          <button type="button" class="btn btn-soft full" style="margin-top:9px" onclick="go('leaderboard')">${ic('trophy')} جدول رتبه‌بندی زنده</button>`)}
      </div>`;
  } else {
    const results = getMyResults(), avg = average(results);
    const available = state.exams.filter(e => !results.some(r => r.examId === e.id));
    const lastScore = results.length ? results[results.length - 1].score : null;
    const prevScore = results.length > 1 ? results[results.length - 2].score : null;
    const trend = lastScore !== null && prevScore !== null
      ? (lastScore >= prevScore ? `<span class="trend-up">▲ بالاتر از قبل</span>` : `<span class="trend-down">▼ پایین‌تر از قبل</span>`) : '';
    document.getElementById('content').innerHTML = `
      <div class="notice">${ic("spark")} سلام ${esc(user.name)}! آماده‌ای امروز یک قدم به هدفت نزدیک‌تر بشی؟</div>
      <div class="grid stats">
        ${stat('trophy', 'purple', 'میانگین نمرات', results.length ? faNum(avg) : '—', results.length ? 'از ۱۰۰' : '')}
        ${stat('book', 'green', 'آزمون‌های انجام‌شده', faNum(results.length), 'آزمون')}
        ${stat('clock', 'blue', 'آزمون‌های پیش رو', faNum(available.length), 'آزمون')}
        ${stat('trend', 'orange', 'آخرین نمره', lastScore !== null ? faNum(lastScore) : '—', lastScore !== null ? 'از ۱۰۰' : '')}
      </div>
      <div class="grid two-col">
        ${panel('نمودار پیشرفت', results.length ? chartSvg(results.map(r => r.score)) : `<div class="empty">با شرکت در اولین آزمون، نمودار پیشرفتت اینجا نمایش داده می‌شه</div>`, `<button type="button" class="link-btn" onclick="go('progress')">جزئیات ←</button>`)}
        ${panel('آزمون‌هایی که باید بدهی', available.length ? `<div class="exam-list">${available.slice(0, 3).map(e => examRow(e, 'شروع', 'startExam')).join('')}</div>` : `<div class="empty">فعلاً آزمون جدیدی نداری</div>`, `<button type="button" class="link-btn" onclick="go('exams')">همه آزمون‌ها ←</button>`)}
      </div>
      <div class="grid two-col">
        ${panel('آخرین نمرات', results.length ? results.slice(-3).reverse().map(r => `<div class="exam-row"><div class="exam-icon">${ic("check")}</div><div class="exam-info"><strong>${esc(r.title)}</strong><small>${esc(r.dateTaken)}</small></div><b class="score-pill">${faNum(r.score)}/۱۰۰</b></div>`).join('') : `<div class="empty">هنوز نمره‌ای ثبت نشده است.</div>`)}
        ${panel('رتبه تو در کلاس', myRankBlock(), `<button type="button" class="link-btn" onclick="go('leaderboard')">جدول کامل ←</button>`)}
      </div>`;
  }
}

/* ---------- ساخت آزمون (معلم) ---------- */
let questionCount = 0;
function questionBlock(i) {
  return `<div class="question-builder" id="question-${i}">
    <div class="panel-head"><h3>سؤال ${faNum(i + 1)}</h3>${i > 0 ? `<button type="button" class="btn btn-danger" onclick="removeQuestion(${i})">حذف سؤال</button>` : ''}</div>
    <div class="field"><label>متن سؤال *</label><textarea id="qText${i}" rows="2" placeholder="متن سؤال را بنویس..." required></textarea></div>
    <div class="option-grid">${[0, 1, 2, 3].map(n => `<div class="field"><label>گزینه ${['الف', 'ب', 'ج', 'د'][n]} *</label><input id="opt${i}_${n}" required placeholder="متن گزینه"></div>`).join('')}</div>
    <div class="field"><label>پاسخ صحیح</label><select id="correct${i}"><option value="0">گزینه الف</option><option value="1">گزینه ب</option><option value="2">گزینه ج</option><option value="3">گزینه د</option></select></div>
  </div>`;
}
function addQuestion() {
  const holder = document.getElementById('questionsHolder');
  if (!holder) return;
  holder.insertAdjacentHTML('beforeend', questionBlock(questionCount++));
}
function removeQuestion(i) { document.getElementById('question-' + i)?.remove(); }

function renderCreate() {
  questionCount = 0;
  document.getElementById('content').innerHTML = `
    <div class="notice">${ic("book")} مشخصات آزمون را وارد کن و با «افزودن سؤال» هر تعداد سؤال لازم داری اضافه کن.</div>
    <section class="panel"><div class="panel-head"><h2>مشخصات آزمون جدید</h2><span class="badge">ساخت آزمون</span></div>
    <form id="examForm" novalidate>
      <div class="form-grid">
        <div class="field"><label>نام آزمون *</label><input id="examTitle" required placeholder="مثلاً آزمون فصل اول زیست"></div>
        <div class="field"><label>تاریخ برگزاری</label><input id="examDate" type="date"></div>
        <div class="field"><label>مدت آزمون (دقیقه)</label><input id="examDuration" type="number" min="1" max="180" value="15" required></div>
        <div class="field"><label>توضیحات</label><input id="examDesc" placeholder="مباحث و نکات آزمون"></div>
      </div>
      <div id="questionsHolder"></div>
      <button type="button" class="btn btn-soft" onclick="addQuestion()">${ic("plus")} افزودن سؤال</button>
      <div style="height:16px"></div>
      <button class="btn btn-primary" type="submit" id="saveExamBtn">ذخیره آزمون</button>
      <button type="button" class="btn btn-soft" onclick="go('questions')">انصراف</button>
    </form></section>`;
  addQuestion();
  document.getElementById('examForm').onsubmit = submitExamForm;
}

async function submitExamForm(e) {
  e.preventDefault();
  const blocks = [...document.querySelectorAll('#questionsHolder .question-builder')];
  if (!blocks.length) { toast('حداقل یک سؤال اضافه کن'); return; }
  const questions = blocks.map(el => {
    const i = Number(el.id.replace('question-', ''));
    return {
      text: document.getElementById('qText' + i).value.trim(),
      options: [0, 1, 2, 3].map(n => document.getElementById('opt' + i + '_' + n).value.trim()),
      correct: Number(document.getElementById('correct' + i).value)
    };
  });
  if (questions.some(q => !q.text || q.options.some(o => !o))) { toast('متن سؤال و هر چهار گزینه را کامل کن'); return; }
  const title = document.getElementById('examTitle').value.trim();
  if (!title) { toast('نام آزمون را وارد کن'); return; }
  const btn = document.getElementById('saveExamBtn'); btn.disabled = true;
  try {
    const { data: { user: authUser } } = await sb.auth.getUser();
    if (!authUser) { toast('نشست ورود پیدا نشد؛ دوباره وارد شو'); return; }
    const examPayload = {
      title, exam_date: document.getElementById('examDate').value || null,
      duration: Number(document.getElementById('examDuration').value) || 15,
      description: document.getElementById('examDesc').value.trim(),
      status: 'آماده', created_by: authUser.id
    };
    const { data: examRow, error: examError } = await sb.from('zistium_exams').insert(examPayload).select('id').single();
    if (examError) { toast('ذخیره آزمون ناموفق بود: ' + examError.message); return; }
    // ثبت گروهی سؤال‌ها — سریع‌تر از حلقه تکی
    const { data: qRows, error: qError } = await sb.from('zistium_questions').insert(
      questions.map((q, i) => ({ exam_id: examRow.id, question_text: q.text, options: q.options, position: i }))
    ).select('id');
    if (qError) { toast('آزمون ساخته شد اما ذخیره سؤال‌ها ناموفق بود: ' + qError.message); return; }
    const { error: keyError } = await sb.from('zistium_answer_keys').insert(
      qRows.map((qr, i) => ({ question_id: qr.id, correct_answer: questions[i].correct }))
    );
    if (keyError) { toast('سؤال‌ها ذخیره شدند اما کلید پاسخ خطا داد: ' + keyError.message); return; }
    await loadExamsFromDatabase();
    toast(`آزمون و ${faNum(questions.length)} سؤال در دیتابیس ذخیره شد`);
    go('questions');
  } finally { btn.disabled = false; }
}

/* ---------- مدیریت آزمون‌ها ---------- */
function renderManage() {
  document.getElementById('content').innerHTML = `<div class="panel"><div class="panel-head"><div><h2>آزمون‌های ساخته‌شده</h2><p>آزمون‌ها از دیتابیس آنلاین Supabase خوانده می‌شوند.</p></div><button type="button" class="btn btn-primary" onclick="go('create')">${'`'}+ آزمون جدید</button></div>
  ${state.exams.length ? `<div class="table-wrap"><table><thead><tr><th>نام آزمون</th><th>تاریخ</th><th>تعداد سؤال</th><th>مدت</th><th>عملیات</th></tr></thead><tbody>
  ${state.exams.map(e => `<tr><td><strong>${esc(e.title)}</strong><br><small style="color:var(--muted)">${esc(e.desc || '')}</small></td><td>${esc(e.date || '—')}</td><td>${faNum(e.questions.length)}</td><td>${faNum(e.duration)} دقیقه</td><td><div class="actions"><button type="button" class="btn btn-soft" onclick="previewExam('${e.id}')">پیش‌نمایش</button><button type="button" class="btn btn-danger" onclick="deleteExam('${e.id}')">حذف</button></div></td></tr>`).join('')}
  </tbody></table></div>` : `<div class="empty">هنوز آزمونی نساختی. اولین آزمونت رو ایجاد کن!</div>`}</div>`;
}

function renderStudents() {
  const rows = state.results;
  document.getElementById('content').innerHTML = `<div class="panel"><div class="panel-head"><div><h2>نتایج ثبت‌شده</h2><p>نتایج واقعی ذخیره‌شده در Supabase</p></div><span class="badge done">${faNum(rows.length)} نتیجه</span></div>
  ${rows.length ? `<div class="table-wrap"><table><thead><tr><th>نام دانش‌آموز</th><th>آزمون</th><th>نمره</th><th>تاریخ</th></tr></thead><tbody>
  ${rows.map(r => `<tr><td>${esc(r.student)}</td><td>${esc(r.title)}</td><td><b class="score-pill">${faNum(r.score)}/۱۰۰</b></td><td>${esc(r.dateTaken)}</td></tr>`).join('')}
  </tbody></table></div>` : `<div class="empty">بعد از اینکه دانش‌آموزها آزمون بدهند، نتایج اینجا دیده می‌شود.</div>`}</div>`;
}

function renderExams() {
  const done = getMyResults().map(r => r.examId);
  document.getElementById('content').innerHTML = `<div class="panel"><div class="panel-head"><h2>آزمون‌های در دسترس</h2><span class="badge">${faNum(state.exams.length)} آزمون</span></div>
  ${state.exams.length ? `<div class="exam-list">${state.exams.map(e => examRow(e, done.includes(e.id) ? 'مشاهده نمره' : 'شروع آزمون', done.includes(e.id) ? 'viewResult' : 'startExam', done.includes(e.id) ? 'برگزار شده' : 'در انتظار')).join('')}</div>` : `<div class="empty">هنوز آزمونی توسط معلم ثبت نشده است.</div>`}</div>`;
}

function renderProgress() {
  const r = getMyResults();
  document.getElementById('content').innerHTML = `
    <div class="grid stats">
      ${stat('trend', 'green', 'میانگین نمرات', r.length ? faNum(average(r)) : '—', r.length ? 'از ۱۰۰' : '')}
      ${stat('check', 'purple', 'تعداد آزمون‌ها', faNum(r.length), 'آزمون')}
      ${stat('trophy', 'blue', 'بالاترین نمره', r.length ? faNum(Math.max(...r.map(x => x.score))) : '—', r.length ? 'از ۱۰۰' : '')}
      ${stat('leaf', 'orange', 'روند کلی', r.length > 1 ? (r[r.length - 1].score >= r[0].score ? 'رو به رشد' : 'نیاز به تمرین') : 'در حال شروع', '')}
    </div>
    ${panel('روند نمرات تو', r.length ? chartSvg(r.map(x => x.score)) : `<div class="empty">برای نمایش نمودار، در یک آزمون شرکت کن.</div>`)}
    ${panel('جزئیات آزمون‌ها', r.length ? `<div class="table-wrap"><table><thead><tr><th>آزمون</th><th>نمره</th><th>درصد</th><th>تاریخ</th></tr></thead><tbody>
      ${r.map(x => `<tr><td>${esc(x.title)}</td><td>${faNum(x.score)}/۱۰۰</td><td><div class="progress-track" style="width:100px"><span style="width:${x.score}%"></span></div></td><td>${esc(x.dateTaken)}</td></tr>`).join('')}
    </tbody></table></div>` : `<div class="empty">هنوز نتیجه‌ای برای نمایش وجود ندارد.</div>`)}`;
}

function renderResults() {
  const r = getMyResults();
  document.getElementById('content').innerHTML = panel('نمرات من', r.length
    ? `<div class="table-wrap"><table><thead><tr><th>آزمون</th><th>نمره</th><th>درصد پاسخ صحیح</th><th>تاریخ</th></tr></thead><tbody>
      ${r.slice().reverse().map(x => `<tr><td>${esc(x.title)}</td><td><b class="score-pill">${faNum(x.score)}/۱۰۰</b></td><td>${x.totalQuestions ? `${faNum(x.correctCount ?? Math.round(x.score * x.totalQuestions / 100))} از ${faNum(x.totalQuestions)}` : '—'}</td><td>${esc(x.dateTaken)}</td></tr>`).join('')}
    </tbody></table></div>` : `<div class="empty">هنوز نمره‌ای برای تو ثبت نشده است.</div>`);
}

/* ---------- آزمون‌دهی ---------- */
function startExam(id) {
  const e = state.exams.find(x => x.id === id);
  if (!e) return;
  if (getMyResults().some(r => r.examId === id)) { toast('این آزمون را قبلاً انجام داده‌ای.'); return; }
  if (!e.questions.length) { toast('این آزمون هنوز سؤال ندارد.'); return; }
  activeExam = e; examAnswers = {}; go('take');
}

function renderTake() {
  if (!activeExam) { go('exams'); return; }
  const e = activeExam;
  if (!e.questions.length) { toast('این آزمون سؤال ندارد.'); activeExam = null; go('exams'); return; }
  document.getElementById('content').innerHTML = `
    <div class="panel"><div class="panel-head"><div><h2>${esc(e.title)}</h2><p>${faNum(e.questions.length)} سؤال · ${faNum(e.duration)} دقیقه</p></div><div class="timer" id="timer">${faNum(e.duration)}:۰۰</div></div>
    <form id="takeForm">
      ${e.questions.map((q, i) => `<div class="question-card"><h3>سؤال ${faNum(i + 1)}: ${esc(q.text)}</h3>
        ${q.options.map((o, j) => `<label class="answer-option"><input type="radio" name="q${i}" value="${j}" required> <span>${['الف', 'ب', 'ج', 'د'][j]}) ${esc(o)}</span></label>`).join('')}
      </div>`).join('')}
      <button class="btn btn-primary" type="submit">ثبت پاسخ‌ها و دیدن نمره</button>
      <button type="button" class="btn btn-soft" onclick="go('exams')">بازگشت</button>
    </form></div>`;
  let left = e.duration * 60;
  clearInterval(examTimer);
  const tick = () => {
    const el = document.getElementById('timer');
    if (!el) { clearInterval(examTimer); return; }
    el.textContent = faNum(Math.floor(left / 60)) + ':' + faNum(String(left % 60).padStart(2, '0'));
    el.classList.toggle('danger', left <= 30);
    if (left <= 0) { clearInterval(examTimer); toast('زمان آزمون تمام شد!'); submitExam(); return; }
    left--;
  };
  tick(); examTimer = setInterval(tick, 1000);
  document.getElementById('takeForm').onsubmit = ev => { ev.preventDefault(); submitExam(); };
}

async function submitExam() {
  if (!activeExam) return;
  clearInterval(examTimer);
  const form = document.getElementById('takeForm');
  const answers = activeExam.questions.map((q, i) => {
    const chosen = form?.querySelector(`input[name="q${i}"]:checked`);
    return { question_id: q.id, selected_answer: chosen ? Number(chosen.value) : null };
  });
  if (answers.some(a => a.selected_answer === null)) { toast('لطفاً به همه سؤال‌ها پاسخ بده.'); renderTake(); return; }
  const exam = activeExam;
  const { data, error } = await sb.rpc('submit_zistium_exam', { p_exam_id: exam.id, p_answers: answers });
  if (error) { toast('ثبت آزمون ناموفق بود: ' + error.message); return; }
  const result = Array.isArray(data) ? data[0] : data;
  if (!result) { toast('نمره دریافت نشد؛ دوباره تلاش کن.'); return; }
  activeExam = null;
  await Promise.all([loadResultsFromDatabase()]);
  toast(`آزمون ثبت شد؛ نمره‌ات ${faNum(result.score)} از ۱۰۰ است`);
  go('results');
}

function viewResult(id) {
  const r = state.results.find(x => x.examId === id && (x.studentId === user.id || (!x.studentId && x.student === user.name)));
  if (r) toast(`نمره این آزمون: ${faNum(r.score)} از ۱۰۰`);
}

/* ---------- مدیریت (معلم) ---------- */
function previewExam(id) {
  const e = state.exams.find(x => x.id === id);
  if (!e) return;
  alert(e.title + '\n\n' + e.questions.map((q, i) => (i + 1) + '. ' + q.text).join('\n'));
}
async function deleteExam(id) {
  if (!confirm('از حذف این آزمون مطمئنی؟ همه سؤال‌ها و نتایج آن هم حذف می‌شود.')) return;
  const { error } = await sb.from('zistium_exams').delete().eq('id', id);
  if (error) { toast('حذف ناموفق بود: ' + error.message); return; }
  await Promise.all([loadExamsFromDatabase(), loadResultsFromDatabase()]);
  renderManage(); toast('آزمون از دیتابیس حذف شد.');
}

/* ---------- جدول رتبه‌بندی زنده ---------- */
function rankMedal(rank) {
  if (rank === 1) return '<span class="rank-cell rank-1">۱</span>';
  if (rank === 2) return '<span class="rank-cell rank-2">۲</span>';
  if (rank === 3) return '<span class="rank-cell rank-3">۳</span>';
  return `<span class="rank-cell">${faNum(rank)}</span>`;
}

function buildRanking() {
  // میانگین نمره هر دانش‌آموز روی همه آزمون‌ها
  const byStudent = {};
  for (const r of state.results) {
    const key = r.studentId || r.student;
    if (!byStudent[key]) byStudent[key] = { name: r.student, id: r.studentId || '', scores: [], correct: 0, total: 0, last: null };
    byStudent[key].scores.push(r.score);
    byStudent[key].correct += (r.correctCount ?? 0);
    byStudent[key].total += (r.totalQuestions ?? 0);
    const t = r.createdAt ? new Date(r.createdAt).getTime() : 0;
    if (t > (byStudent[key].last || 0)) byStudent[key].last = t;
  }
  const rows = Object.values(byStudent).map(s => ({
    ...s,
    avg: Math.round(s.scores.reduce((a, b) => a + b, 0) / s.scores.length),
    exams: s.scores.length,
    best: Math.max(...s.scores)
  }));
  rows.sort((a, b) => b.avg - a.avg || b.exams - a.exams || a.name.localeCompare(b.name, 'fa'));
  return rows;
}

function myRankBlock() {
  const ranking = buildRanking();
  if (!ranking.length) return `<div class="empty">هنوز رقابتی شروع نشده؛ اولین آزمون بده و صدر جدول رو فتح کن</div>`;
  const me = ranking.findIndex(r => r.id === user.id || r.name === user.name) + 1;
  const top3 = ranking.slice(0, 3);
  return `
    ${me ? `<div style="margin-bottom:12px;font-size:13px">رتبه تو: ${rankMedal(me)} <b>از ${faNum(ranking.length)} نفر</b> · میانگین ${faNum(ranking[me - 1].avg)}</div>` : ''}
    ${top3.map((r, i) => `<div class="exam-row"><div class="exam-icon">${rankMedal(i + 1)}</div><div class="exam-info"><strong>${esc(r.name)}${(r.id === user.id || r.name === user.name) ? ' <span class="badge done">تو</span>' : ''}</strong><small>میانگین ${faNum(r.avg)} · ${faNum(r.exams)} آزمون</small></div><b class="score-pill">${faNum(r.avg)}</b></div>`).join('')}`;
}

function renderLeaderboard() {
  startLeaderboardLive();
  const examOptions = [`<option value="all">همه آزمون‌ها</option>`,
    ...state.exams.map(e => `<option value="${e.id}" ${lbExamFilter === e.id ? 'selected' : ''}>${esc(e.title)}</option>`)].join('');
  document.getElementById('content').innerHTML = `
    <div class="notice">${ic("trophy")} رتبه‌بندی بر اساس میانگین نمره محاسبه می‌شود و به‌صورت <b>زنده</b> با هر نمره جدید به‌روزرسانی می‌شود — بدون نیاز به رفرش صفحه.</div>
    <div class="panel"><div class="panel-head"><div><h2>جدول رتبه‌بندی زنده</h2><p><span class="live-dot" style="display:inline-block"></span> متصل به دیتابیس — به‌روزرسانی خودکار</p></div>
    <select id="lbExamFilter" class="lb-filter" onchange="onLbFilterChange(this.value)">${examOptions}</select></div>
    <div id="lbBody"></div></div>`;
  drawLeaderboard();
}

function onLbFilterChange(v) { lbExamFilter = v; drawLeaderboard(); }

function drawLeaderboard() {
  const body = document.getElementById('lbBody');
  if (!body) return;
  let results = state.results;
  if (lbExamFilter !== 'all') results = results.filter(r => r.examId === lbExamFilter);
  const ranking = buildRankingFrom(results);
  if (!ranking.length) {
    body.innerHTML = `<div class="empty">هنوز نمره‌ای برای این بخش ثبت نشده است. بعد از اولین آزمون، رتبه‌ها اینجا ظاهر می‌شوند</div>`;
    return;
  }
  body.innerHTML = `<div class="table-wrap"><table><thead><tr><th style="width:56px">رتبه</th><th>دانش‌آموز</th><th>میانگین</th><th>بهترین نمره</th><th>تعداد آزمون</th><th>پاسخ صحیح</th><th>آخرین فعالیت</th></tr></thead><tbody>
    ${ranking.map((r, i) => {
      const isMe = r.id === user.id || r.name === user.name;
      return `<tr style="${isMe ? 'background:rgba(45,212,167,.07)' : ''}">
        <td>${rankMedal(i + 1)}</td>
        <td><strong>${esc(r.name)}</strong>${isMe ? ' <span class="badge done">تو</span>' : ''}</td>
        <td><b class="score-pill">${faNum(r.avg)}</b><div class="progress-track" style="width:90px;margin-top:5px"><span style="width:${r.avg}%"></span></div></td>
        <td>${faNum(r.best)}</td>
        <td>${faNum(r.exams)}</td>
        <td>${r.total ? faNum(r.correct) + ' از ' + faNum(r.total) : '—'}</td>
        <td>${r.last ? new Date(r.last).toLocaleDateString('fa-IR') : '—'}</td>
      </tr>`;
    }).join('')}
  </tbody></table></div>
  <p style="font-size:11px;color:var(--muted);margin:12px 0 0">آخرین به‌روزرسانی: ${new Date().toLocaleTimeString('fa-IR')} · رتبه‌بندی به‌صورت زنده به‌روز می‌شود.</p>`;
}

function buildRankingFrom(results) {
  const byStudent = {};
  for (const r of results) {
    const key = r.studentId || r.student;
    if (!byStudent[key]) byStudent[key] = { name: r.student, id: r.studentId || '', scores: [], correct: 0, total: 0, last: null };
    byStudent[key].scores.push(r.score);
    byStudent[key].correct += (r.correctCount ?? 0);
    byStudent[key].total += (r.totalQuestions ?? 0);
    const t = r.createdAt ? new Date(r.createdAt).getTime() : 0;
    if (t > (byStudent[key].last || 0)) byStudent[key].last = t;
  }
  const rows = Object.values(byStudent).map(s => ({
    ...s, avg: Math.round(s.scores.reduce((a, b) => a + b, 0) / s.scores.length),
    exams: s.scores.length, best: Math.max(...s.scores)
  }));
  rows.sort((a, b) => b.avg - a.avg || b.exams - a.exams || a.name.localeCompare(b.name, 'fa'));
  return rows;
}

function startLeaderboardLive() {
  stopLeaderboardLive();
  // Realtime: هر نمره جدید بلافاصله جدول را به‌روز می‌کند
  try {
    lbChannel = sb.channel('zistium-leaderboard')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'zistium_attempts' }, async () => {
        await loadResultsFromDatabase();
        if (page === 'leaderboard') drawLeaderboard();
        if (page === 'dashboard') renderDashboard();
        toast('نمره جدیدی ثبت شد — جدول رتبه‌بندی به‌روز شد.');
      })
      .subscribe();
  } catch (e) { console.warn('realtime unavailable', e); }
  // پشتیبان: هر ۳۰ ثانیه یک polling سبک
  lbTimer = setInterval(async () => {
    if (page !== 'leaderboard') { stopLeaderboardLive(); return; }
    await loadResultsFromDatabase();
    drawLeaderboard();
  }, 30000);
}
function stopLeaderboardLive() {
  if (lbChannel) { try { sb.removeChannel(lbChannel); } catch {} lbChannel = null; }
  if (lbTimer) { clearInterval(lbTimer); lbTimer = null; }
}

/* ---------- مشاور رسمی زیستیوم (چت بات انصال) ---------- */
const CHAT_API = 'api.php?op=chat';
const CB_WELCOME = 'سلام! من مشاور رسمی زیستیوم هستم.\n\nمی‌تونم:\n• عملکرد تو رو تحلیل کنم و نقاط قوت و ضعفت رو بگم\n• بر اساس نمره‌هات برنامه مطالعه هفتگی بچینم\n• برای آزمون‌های پیش‌رو بهت استراتژی بدم\n\nکافیه بپرسی — مثلاً «برنامه‌ریزی کن برام» یا «وضعیتم رو تحلیل کن».';
const CB_SUGGESTIONS = ['وضعیتم رو تحلیل کن', 'برنامه مطالعه بچین برام', 'چی بخونم؟', 'برای آزمون بعدی چیکار کنم؟'];
let cbOpen = false, cbBusy = false;
let cbHistory = [];

function openChatbot() {
  const panel = document.getElementById('chatbotPanel');
  panel.hidden = false;
  document.body.classList.add('chatbot-open');
  cbOpen = true;
  const body = document.getElementById('chatbotBody');
  if (!body.dataset.init) {
    body.dataset.init = '1';
    cbPush('bot', CB_WELCOME);
    document.getElementById('cbSuggest').innerHTML = CB_SUGGESTIONS.map(s => `<button type="button" onclick="cbQuick('${s}')">${s}</button>`).join('');
  }
  document.getElementById('chatbotInput').focus();
}
function closeChatbot() {
  document.getElementById('chatbotPanel').hidden = true;
  document.body.classList.remove('chatbot-open');
  cbOpen = false;
}
function cbQuick(text) { openChatbot(); document.getElementById('chatbotInput').value = text; cbSend(); }

function cbPush(role, text) {
  const body = document.getElementById('chatbotBody');
  const div = document.createElement('div');
  div.className = 'cb-msg ' + (role === 'user' ? 'user' : 'bot');
  div.textContent = text;
  body.appendChild(div);
  body.scrollTop = body.scrollHeight;
  return div;
}
function cbTyping(on) {
  const body = document.getElementById('chatbotBody');
  let t = document.getElementById('cbTyping');
  if (on && !t) {
    t = document.createElement('div');
    t.className = 'cb-msg bot typing'; t.id = 'cbTyping';
    t.innerHTML = '<i></i><i></i><i></i>';
    body.appendChild(t); body.scrollTop = body.scrollHeight;
  }
  if (!on && t) t.remove();
}

/* تحلیل عملکرد دانش‌آموز برای سیستم مشاوره */
function buildCounselorContext() {
  const my = getMyResults();
  if (!my.length) return 'دانش‌آموز هنوز هیچ آزمونی نداده است. او را تشویق کن اولین آزمونش را بدهد و برنامه عمومی پیشنهاد بده.';
  const lines = my.slice(0, 8).map(r => `- آزمون «${r.title}»: نمره ${r.score} از ۱۰۰ (${r.correctCount ?? '?'} پاسخ صحیح از ${r.totalQuestions ?? '?'} سؤال) — ${r.dateTaken}`);
  const weak = my.filter(r => r.score < 60).map(r => r.title);
  const strong = my.filter(r => r.score >= 85).map(r => r.title);
  const avg = Math.round(my.reduce((a, b) => a + b.score, 0) / my.length);
  const ranking = buildRanking();
  const myRank = ranking.findIndex(r => r.id === user.id || r.name === user.name) + 1;
  let ctx = `آمار واقعی دانش‌آموز «${user.name}» از دیتابیس:\nمیانگین کل: ${avg} از ۱۰۰\nتعداد آزمون: ${my.length}\n` + lines.join('\n');
  if (weak.length) ctx += `\nآزمون‌های ضعیف (نیاز به مرور): ${weak.join('، ')}`;
  if (strong.length) ctx += `\nآزمون‌های قوی: ${strong.join('، ')}`;
  if (myRank) ctx += `\nرتبه او در کلاس: ${myRank} از ${ranking.length} نفر`;
  ctx += `\n\nآزمون‌های در دسترس: ${state.exams.map(e => e.title).join('، ') || 'هیچ'}`;
  return ctx;
}

const CB_SYSTEM_BASE = () => `تو «مشاور رسمی زیستیوم» هستی؛ مشاور تحصیلی هوشمند سامانه آموزش زیست‌شناسی زیستیوم که توسط کمپانی انصال ساخته شده است.
وظایف تو:
۱) تحلیل عملکرد: بر اساس نمرات واقعی که در پیام «سیستم» می‌بینی، نقاط قوت و ضعف دانش‌آموز را دقیق و صادقانه بگو.
۲) برنامه‌ریزی درسی: وقتی خواست برنامه بدهی، یک برنامه مطالعه مشخص با روزهای هفته، ساعات و فصل‌های زیست‌شناسی ارائه بده — اولویت با مباحثی که نمره پایین‌تری گرفته.
۳) انگیزه و استراتژی: برای آزمون‌های پیش‌رو تکنیک مطالعه و مدیریت زمان بگو.

قوانین پاسخ‌دهی:
- همیشه فارسی، گرم و ساده بنویس؛ خطاب به خود دانش‌آموز («تو»).
- پاسخ‌ها کوتاه و ساختارمند باشند؛ از تیتر و بولت استفاده کن ولی متن را بیش از حد طولانی نکن.
- هیچ‌وقت ایموجی نگذار؛ فقط متن.
- اگر سؤال خارج از درس زیست‌شناسی و مشاوره تحصیلی بود، مؤدبانه به موضوع خودت برگرد.
- اگر آماری در دسترس نیست، همان را بگو و سؤال دقیق‌تر بپرس.`;

async function cbSend() {
  if (cbBusy) return;
  const input = document.getElementById('chatbotInput');
  const text = input.value.trim();
  if (!text) return;
  input.value = '';
  cbPush('user', text);
  cbBusy = true;
  document.getElementById('chatbotSend').disabled = true;
  cbTyping(true);
  try {
    const msgs = [
      { role: 'system', content: CB_SYSTEM_BASE() + '\n\n[داده‌های سیستم]\n' + buildCounselorContext() },
      ...cbHistory.slice(-8),
      { role: 'user', content: text }
    ];
    const res = await fetch(CHAT_API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages: msgs, model: 'auto', polish: true })
    });
    const data = await res.json();
    if (data.error) { cbPush('bot', 'خطا: ' + data.error); }
    else {
      cbPush('bot', data.text);
      cbHistory.push({ role: 'user', content: text }, { role: 'assistant', content: data.text });
      cbHistory = cbHistory.slice(-12);
    }
  } catch (e) {
    cbPush('bot', 'ارتباط با مشاور برقرار نشد. مطمئن شو فایل api.php روی هاست PHP کنار سایت قرار دارد و دوباره تلاش کن.');
  } finally {
    cbTyping(false);
    cbBusy = false;
    document.getElementById('chatbotSend').disabled = false;
    document.getElementById('chatbotInput').focus();
  }
}
document.getElementById('chatbotForm').addEventListener('submit', e => { e.preventDefault(); cbSend(); });

/* ---------- صفحه مشاور رسمی ---------- */
function renderCounselor() {
  const my = getMyResults();
  const ranking = buildRanking();
  const myRank = ranking.findIndex(r => r.id === user.id || r.name === user.name) + 1;
  const avg = my.length ? Math.round(my.reduce((a, b) => a + b.score, 0) / my.length) : null;
  const weak = my.filter(r => r.score < 60);
  const strong = my.filter(r => r.score >= 85);
  const insights = [];
  if (avg !== null) {
    insights.push({ cls: avg >= 80 ? 'good' : avg >= 60 ? 'warn' : 'bad', icon: 'trend',
      text: `میانگین کلی تو <b>${faNum(avg)}</b> از ۱۰۰ است. ${avg >= 80 ? 'عملکردت عالی است — همین روند را حفظ کن.' : avg >= 60 ? 'وضعیت قابل قبول است اما با مرور هدفمند می‌تواند خیلی بهتر شود.' : 'به برنامه‌ریزی جدی نیاز داری؛ از مباحث ضعیف شروع کن.'}` });
  }
  if (myRank) insights.push({ cls: myRank <= 3 ? 'good' : 'info', icon: 'trophy',
    text: `رتبه فعلی تو در کلاس <b>${faNum(myRank)}</b> از ${faNum(ranking.length)} نفر است. ${myRank > 3 ? 'با چند آزمون بهتر می‌توانی صعود کنی.' : 'بین سه نفر برتر هستی — آفرین!'}` });
  if (weak.length) insights.push({ cls: 'bad', icon: 'alert',
    text: `در این آزمون‌ها نمره زیر ۶۰ گرفته‌ای و باید مرور شوند: <b>${weak.map(w => esc(w.title)).join('، ')}</b>` });
  if (strong.length) insights.push({ cls: 'good', icon: 'check',
    text: `در <b>${strong.map(s => esc(s.title)).join('، ')}</b> قوی هستی؛ این مباحث را دوره‌ای نگه دار.` });
  if (!my.length) insights.push({ cls: 'info', icon: 'info', text: 'هنوز آزمونی نداده‌ای. اولین آزمونت را بده تا مشاور بتواند تحلیل دقیق و برنامه اختصاصی به تو بدهد.' });

  document.getElementById('content').innerHTML = `
    <div class="counselor-hero">
      <div class="avatar"><svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2l2.4 4.9 5.4.8-3.9 3.8.9 5.4-4.8-2.5-4.8 2.5.9-5.4L4.2 7.7l5.4-.8z"/></svg></div>
      <div>
        <h2>مشاور رسمی زیستیوم</h2>
        <p>مشاور هوشمند تو، ساخته کمپانی انصال. نمرات واقعی تو را از دیتابیس می‌خواند، عملکردت را تحلیل می‌کند و برنامه مطالعه اختصاصی می‌دهد.</p>
        <div style="display:flex;gap:10px;margin-top:12px;flex-wrap:wrap">
          <button type="button" class="btn btn-primary" onclick="openChatbot()">${ic('chat')} گفت‌وگو با مشاور</button>
          ${user.role !== 'teacher' ? `<button type="button" class="btn btn-soft" onclick="cbQuick('برنامه مطالعه بچین برام')">${ic('book')} برنامه مطالعه بگیر</button>` : ''}
        </div>
      </div>
    </div>
    ${panel('تحلیل خودکار عملکرد تو', `<div class="insights-grid">${insights.map(i => `<div class="insight-card ${i.cls}">${ic(i.icon)}<div>${i.text}</div></div>`).join('')}</div>`)}
    ${panel('پرسش‌های پرتکرار', `<div class="cb-suggest" style="padding:0">${CB_SUGGESTIONS.map(s => `<button type="button" onclick="cbQuick('${s}')">${s}</button>`).join('')}</div>`)}
  `;
}
