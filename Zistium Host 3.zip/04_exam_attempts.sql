-- زیستیوم: ثبت پاسخ آزمون و محاسبه نمره در دیتابیس
-- این اسکریپت را یک بار در Supabase > SQL Editor اجرا کنید.

create table if not exists public.zistium_attempts (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references public.zistium_exams(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  answers jsonb not null default '[]'::jsonb,
  score integer not null check (score between 0 and 100),
  correct_count integer not null default 0,
  total_questions integer not null check (total_questions > 0),
  created_at timestamptz not null default now(),
  unique (exam_id, student_id)
);

alter table public.zistium_attempts enable row level security;
drop policy if exists "students read own attempts or teachers read all" on public.zistium_attempts;
create policy "students read own attempts or teachers read all"
on public.zistium_attempts for select to authenticated
using (
  student_id = auth.uid()
  or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'teacher')
);
grant select on public.zistium_attempts to authenticated;
revoke insert, update, delete on public.zistium_attempts from anon, authenticated;

create or replace function public.submit_zistium_exam(p_exam_id uuid, p_answers jsonb)
returns table(attempt_id uuid, score integer, correct_count integer, total_questions integer)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_total integer;
  v_correct integer;
  v_score integer;
  v_attempt_id uuid;
  v_answer_count integer;
begin
  if v_uid is null then raise exception 'ابتدا وارد حساب شو.'; end if;
  if not exists (select 1 from public.profiles p where p.id = v_uid and p.role = 'student') then
    raise exception 'فقط حساب دانش‌آموز می‌تواند آزمون بدهد.';
  end if;
  if jsonb_typeof(p_answers) <> 'array' then raise exception 'پاسخ‌ها معتبر نیستند.'; end if;
  select count(*) into v_total from public.zistium_questions q where q.exam_id = p_exam_id;
  if v_total = 0 then raise exception 'این آزمون سؤال ندارد.'; end if;
  select count(*) into v_answer_count from jsonb_array_elements(p_answers);
  if v_answer_count <> v_total then raise exception 'تعداد پاسخ‌ها با تعداد سؤال‌ها برابر نیست.'; end if;
  if exists (
    select 1 from jsonb_array_elements(p_answers) a
    where coalesce(a->>'question_id','') = '' or coalesce(a->>'selected_answer','') = ''
  ) then raise exception 'به همه سؤال‌ها پاسخ بده.'; end if;
  if exists (
    select 1 from jsonb_array_elements(p_answers) a
    left join public.zistium_questions q on q.id = (a->>'question_id')::uuid and q.exam_id = p_exam_id
    where q.id is null or (a->>'selected_answer')::integer not between 0 and 3
  ) then raise exception 'پاسخ نامعتبر است.'; end if;
  select count(*) into v_correct
  from jsonb_array_elements(p_answers) a
  join public.zistium_answer_keys k on k.question_id = (a->>'question_id')::uuid
  where k.correct_answer = (a->>'selected_answer')::integer;
  v_score := round((v_correct::numeric * 100) / v_total)::integer;
  insert into public.zistium_attempts(exam_id, student_id, answers, score, correct_count, total_questions)
  values(p_exam_id, v_uid, p_answers, v_score, v_correct, v_total)
  returning id into v_attempt_id;
  return query select v_attempt_id, v_score, v_correct, v_total;
exception
  when unique_violation then raise exception 'این آزمون را قبلاً انجام داده‌ای.';
end;
$$;
revoke all on function public.submit_zistium_exam(uuid, jsonb) from public;
grant execute on function public.submit_zistium_exam(uuid, jsonb) to authenticated;
