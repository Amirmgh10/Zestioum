-- زیستیوم — جدول زنده رتبه‌بندی (Leaderboard)
-- این فایل را یک بار در Supabase > SQL Editor اجرا کن (بعد از 03 و 04).

-- ویوی امن: فقط داده‌های عمومی نمره را نمایش می‌دهد (بدون پاسخ‌های jsonb)
create or replace view public.zistium_leaderboard as
select
  a.id,
  a.exam_id,
  a.student_id,
  a.score,
  a.correct_count,
  a.total_questions,
  a.created_at,
  p.username  as student_name,
  e.title     as exam_title
from public.zistium_attempts a
join public.profiles      p on p.id = a.student_id
join public.zistium_exams e on e.id = a.exam_id;

grant select on public.zistium_leaderboard to authenticated;

-- فعال‌سازی Realtime روی جدول تلاش‌ها تا رتبه‌بندی زنده آپدیت شود
do $$
begin
  begin
    alter publication supabase_realtime add table public.zistium_attempts;
  exception when duplicate_object then null;
  end;
end $$;
