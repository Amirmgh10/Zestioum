<?php
/**
 * انصال — نسخه‌ی PHP برای هاست‌های اشتراکی cPanel
 * معادل کامل server.py: چت، جست‌وجوی وب، تولید تصویر، تحلیل تصویر، ویرایش تصویر
 * مسیرها با .htaccess به این فایل بازنویسی می‌شوند: /api/chat و ...
 */
error_reporting(0);
@set_time_limit(300);

header('X-Content-Type-Options: nosniff');
header('Content-Type: application/json; charset=utf-8');

$OP = isset($_GET['op']) ? $_GET['op'] : '';
$VALID_OPS = array('models', 'chat', 'search', 'image', 'vision', 'edit');
if (!in_array($OP, $VALID_OPS)) { http_response_code(404); exit; }

/* ---------------------------------------------------------------- تنظیمات */
$BASE = __DIR__;
$CONFIG = array();
$cfg_raw = @file_get_contents($BASE . '/config.json');
if ($cfg_raw) { $CONFIG = json_decode($cfg_raw, true) ?: array(); }

$UA = 'AnsalEduBot/2.0';

$PROVIDERS = array(
    array('id' => 'groq', 'label' => 'Groq (سریع و رایگان)',
          'base' => 'https://api.groq.com/openai/v1',
          'model' => 'llama-3.3-70b-versatile'),
    array('id' => 'xai', 'label' => 'xAI (Grok)',
          'base' => 'https://api.x.ai/v1',
          'model' => 'grok-4-fast'),
    array('id' => 'openrouter', 'label' => 'OpenRouter (مدل‌های رایگان)',
          'base' => 'https://openrouter.ai/api/v1',
          'model' => 'meta-llama/llama-3.3-70b-instruct:free'),
);

$POLL_URL = 'https://text.pollinations.ai/';
$POLL_DEFAULT = array('openai-fast', 'openai', 'mistral', 'openai-large');
$POLL_KNOWN = array('openai-fast' => 1, 'openai' => 1, 'openai-large' => 1, 'mistral' => 1, 'gemini' => 1);
$POLL_IMG = 'https://image.pollinations.ai/prompt/{q}?width={w}&height={h}&nologo=true&seed={s}&model=flux';

function cfg($arr, $key, $default) {
    return (is_array($arr) && isset($arr[$key]) && $arr[$key] !== '') ? $arr[$key] : $default;
}

function get_key($name) {
    global $CONFIG;
    $env = getenv(strtoupper($name) . '_API_KEY');
    if ($env && trim($env) !== '') { return trim($env); }
    $keys = cfg($CONFIG, 'keys', array());
    return trim(cfg($keys, $name, ''));
}

foreach ($PROVIDERS as $i => $p) {
    $PROVIDERS[$i]['key'] = get_key($p['id']);
    $models = cfg($CONFIG, 'models', array());
    $PROVIDERS[$i]['model'] = cfg($models, $p['id'], $p['model']);
    $bases = cfg($CONFIG, 'base_urls', array());
    $PROVIDERS[$i]['base'] = cfg($bases, $p['id'], $p['base']);
}
$ENABLED = array();
foreach ($PROVIDERS as $p) { if ($p['key'] !== '') { $ENABLED[] = $p; } }

function provider_by_id($id) {
    global $ENABLED;
    foreach ($ENABLED as $p) { if ($p['id'] === $id) { return $p; } }
    return null;
}
$VISION_MODEL = cfg(cfg($CONFIG, 'models', array()), 'vision', 'qwen/qwen3.8-27b');
$TAVILY_KEY = get_key('tavily');
$ACCESS_KEY = trim(cfg($CONFIG, 'access_key', ''));
$RATE_LIMIT = (int) cfg($CONFIG, 'rate_limit_per_minute', 20);
$HAS_GD = function_exists('imagecreatetruecolor');

/* ---------------------------------------------------------------- ابزار */
function out_json($code, $obj) {
    http_response_code($code);
    echo json_encode($obj, JSON_UNESCAPED_UNICODE);
    exit;
}

class HttpErr extends Exception { public $code; public function __construct($code) { $this->code = $code; parent::__construct('HTTP ' . $code); } }

function http_json($url, $body, $headers = array(), $timeout = 60) {
    global $UA;
    $ch = curl_init($url);
    curl_setopt_array($ch, array(
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($body, JSON_UNESCAPED_UNICODE),
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTPHEADER => array_merge(array('Content-Type: application/json', 'User-Agent: ' . $UA), $headers),
    ));
    $r = curl_exec($ch);
    if ($r === false) { $e = curl_error($ch); curl_close($ch); throw new Exception('curl: ' . $e); }
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code >= 400) { throw new HttpErr($code); }
    return $r;
}

function http_get_binary($url, $timeout = 120) {
    global $UA;
    $ch = curl_init($url);
    curl_setopt_array($ch, array(
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_USERAGENT => $UA,
    ));
    $r = curl_exec($ch);
    if ($r === false) { $e = curl_error($ch); curl_close($ch); throw new Exception('curl: ' . $e); }
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code >= 400) { throw new HttpErr($code); }
    return $r;
}

function clean($text) {
    return trim(preg_replace('/<think>.*?<\/think>/s', '', (string) $text));
}

function rate_limited() {
    global $RATE_LIMIT;
    $ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'x';
    $f = sys_get_temp_dir() . '/ansal_rl_' . md5($ip);
    $now = time();
    $hits = array();
    if (is_file($f)) { $hits = json_decode((string) @file_get_contents($f), true); if (!is_array($hits)) { $hits = array(); } }
    $fresh = array();
    foreach ($hits as $t) { if (is_int($t) && $now - $t < 60) { $fresh[] = $t; } }
    if (count($fresh) >= $RATE_LIMIT) { @file_put_contents($f, json_encode($fresh), LOCK_EX); return true; }
    $fresh[] = $now;
    @file_put_contents($f, json_encode($fresh), LOCK_EX);
    return false;
}

function read_payload() {
    $len = isset($_SERVER['CONTENT_LENGTH']) ? (int) $_SERVER['CONTENT_LENGTH'] : 0;
    if ($len > 7000000) { out_json(400, array('error' => 'بدنه‌ی درخواست بزرگ است')); }
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    if (!is_array($data)) { out_json(400, array('error' => 'بدنه‌ی نامعتبر است')); }
    return $data;
}

/* ---------------------------------------------------------------- موتور چت */
function call_provider($p, $messages, $temperature) {
    $raw = http_json($p['base'] . '/chat/completions',
        array('model' => $p['model'], 'messages' => $messages, 'temperature' => $temperature),
        array('Authorization: Bearer ' . $p['key']));
    $j = json_decode($raw, true);
    $text = isset($j['choices'][0]['message']['content']) ? clean($j['choices'][0]['message']['content']) : '';
    if ($text === '') { throw new Exception('پاسخ خالی'); }
    return $text;
}

function call_pollinations($model, $messages) {
    global $POLL_URL;
    $raw = http_json($POLL_URL, array('model' => $model, 'messages' => $messages, 'seed' => 42), array(), 15);
    $text = clean($raw);
    if ($text === '' || strpos(substr($text, 0, 80), 'Free limit reached') !== false) {
        throw new Exception('موتور بدون کلید در دسترس نیست');
    }
    return $text;
}

function build_chain($choice) {
    global $ENABLED, $POLL_DEFAULT, $POLL_KNOWN;
    $chain = array();
    foreach ($ENABLED as $p) { $chain[] = array('provider', $p); }
    $poll = array();
    foreach ($POLL_DEFAULT as $m) { $poll[] = array('poll', $m); }
    $chosen = -1;
    foreach ($chain as $i => $it) { if ($it[1]['id'] === $choice) { $chosen = $i; } }
    if ($chosen >= 0) {
        $c = $chain[$chosen]; array_splice($chain, $chosen, 1);
        array_unshift($chain, $c);
    } elseif (isset($POLL_KNOWN[$choice])) {
        $newpoll = array(array('poll', $choice));
        foreach ($poll as $x) { if ($x[1] !== $choice) { $newpoll[] = $x; } }
        $poll = $newpoll;
    }
    return array_merge($chain, $poll);
}

$POLISH_SYS = 'تو ویراستار حرفه‌ی زبان فارسی هستی. متن آموزشیِ زیر را از نظر نگارش بازنویسی کن: '
    . 'جمله‌ها طبیعی و روان و به فارسی معیار (سبک کتاب‌های درسی ایران) باشند، ترجمه‌وار نباشند, '
    . 'املا و نیم‌فاصله درست باشد و علائم نگارشی فارسی رعایت شود. '
    . 'معنی، درستیِ علمی، اعداد، فرمول‌ها، ساختار (تیترها و فهرست‌ها) و شماره‌ی منبع‌ها مثل [۱] را '
    . 'دقیقاً حفظ کن و چیزی اضافه یا کم نکن. فقط خودِ متن ویراسته را بنویس، بدون هیچ توضیحی.';

function ask($messages, $choice, $temperature) {
    global $ENABLED;
    $chain = build_chain($choice);
    $attempts = count($ENABLED) ? 1 : 2;
    $tried = array();
    for ($attempt = 0; $attempt < $attempts; $attempt++) {
        foreach ($chain as $it) {
            list($kind, $item) = $it;
            $name = $kind === 'provider' ? $item['id'] : 'pollinations:' . $item;
            try {
                if ($kind === 'provider') {
                    return array(call_provider($item, $messages, $temperature), $item['label']);
                }
                return array(call_pollinations($item, $messages), 'موتور بدون کلید');
            } catch (HttpErr $e) {
                $tried[] = $name . ': HTTP ' . $e->code;
            } catch (Exception $e) {
                $tried[] = $name . ': ' . mb_substr($e->getMessage(), 0, 80);
            }
        }
        if ($attempt === 0 && $attempts === 2) { sleep(3); }
    }
    throw new Exception(implode('; ', $tried));
}

function polish($text) {
    try {
        list($new, $label) = ask(array(
            array('role' => 'system', 'content' => $GLOBALS['POLISH_SYS']),
            array('role' => 'user', 'content' => $text)), 'auto', 0.2);
        $ratio = mb_strlen($new) / max(mb_strlen($text), 1);
        if ($ratio >= 0.6 && $ratio <= 1.5) { return $new; }
    } catch (Exception $e) { /* ویرایش نگارشی انجام نشد */ }
    return $text;
}

function clean_messages($msgs) {
    $out = array();
    if (!is_array($msgs)) { return $out; }
    $msgs = array_slice($msgs, -14);
    foreach ($msgs as $m) {
        if (is_array($m) && isset($m['role'], $m['content']) && is_string($m['content'])
            && in_array($m['role'], array('system', 'user', 'assistant'), true)) {
            $out[] = array('role' => $m['role'], 'content' => mb_substr($m['content'], 0, 24000));
        }
    }
    return $out;
}

/* ---------------------------------------------------------------- تصویر */
function parse_dataurl($dataurl) {
    if (!is_string($dataurl) || strpos($dataurl, ';base64,') === false) {
        throw new Exception('قالب تصویر نامعتبر است');
    }
    $parts = explode(';base64,', $dataurl, 2);
    $raw = base64_decode($parts[1], false);
    if ($raw === false || strlen($raw) > 5000000) {
        throw new Exception('تصویر بزرگ‌تر از ۵ مگابایت است');
    }
    return $raw;
}

function shrink_image_raw($raw, $maxSide = 1152, $quality = 85) {
    $im = @imagecreatefromstring($raw);
    if (!$im) { throw new Exception('تصویر قابل خواندن نیست'); }
    $w = imagesx($im); $h = imagesy($im);
    if (max($w, $h) > $maxSide) {
        if ($w >= $h) { $nw = $maxSide; $nh = max(1, (int) round($h * $maxSide / $w)); }
        else { $nh = $maxSide; $nw = max(1, (int) round($w * $maxSide / $h)); }
        $im2 = imagescale($im, $nw, $nh);
        if ($im2) { $im = $im2; }
    }
    ob_start();
    imagejpeg($im, null, $quality);
    $out = ob_get_clean();
    imagedestroy($im);
    return $out;
}

/* ---------------------------------------------------------------- عملیات‌ها */
function api_vision($payload) {
    global $ENABLED, $VISION_MODEL;
    $groq = provider_by_id('groq');
    if (!$groq) { throw new Exception('برای تحلیل تصویر به کلید Groq نیاز است.'); }
    $q = trim(mb_substr((string) (isset($payload['question']) ? $payload['question'] : ''), 0, 2000));
    if ($q === '') { $q = 'این تصویر را بررسی و توضیح بده.'; }
    $raw = parse_dataurl(isset($payload['image']) ? $payload['image'] : '');
    $small = shrink_image_raw($raw);
    $b64 = base64_encode($small);
    $body = array('model' => $VISION_MODEL, 'temperature' => 0.3,
        'messages' => array(array('role' => 'user', 'content' => array(
            array('type' => 'text', 'text' => $q),
            array('type' => 'image_url', 'image_url' => array('url' => 'data:image/jpeg;base64,' . $b64)),
        ))));
    $out = http_json($groq['base'] . '/chat/completions', $body,
        array('Authorization: Bearer ' . $groq['key']), 120);
    $j = json_decode($out, true);
    $text = isset($j['choices'][0]['message']['content']) ? clean($j['choices'][0]['message']['content']) : '';
    if ($text === '') { throw new Exception('پاسخ خالی'); }
    return $text;
}

function api_image($payload) {
    global $POLL_IMG, $UA;
    $prompt = trim(mb_substr((string) (isset($payload['prompt']) ? $payload['prompt'] : ''), 0, 800));
    if ($prompt === '') { throw new Exception('توضیح تصویر خالی است'); }
    $w = (int) (isset($payload['width']) ? $payload['width'] : 1024);
    $h = (int) (isset($payload['height']) ? $payload['height'] : 1024);
    $w = max(256, min($w ?: 1024, 1280));
    $h = max(256, min($h ?: 1024, 1280));
    $url = strtr($POLL_IMG, array(
        '{q}' => rawurlencode($prompt), '{w}' => $w, '{h}' => $h,
        '{s}' => (string) rand(1, 1000000000),
    ));
    // سرویس رایگان هر ۴۵ ثانیه یک تصویر به‌ازای هر IP می‌دهد؛ صبر و تلاش مجدد
    $raw = null;
    foreach (array(0, 25, 55, 85) as $wait) {
        if ($wait) { sleep($wait); }
        try { $raw = http_get_binary($url); break; }
        catch (HttpErr $e) {
            if (!in_array($e->code, array(402, 429, 503), true)) { throw $e; }
        }
    }
    if ($raw === null) { throw new Exception('سرویس تصویر شلوغ است؛ یک دقیقه دیگر دوباره امتحان کن'); }
    $im = @imagecreatefromstring($raw);
    if (!$im) { throw new Exception('تصویر تولیدشده قابل خواندن نیست'); }
    if (imageistruecolor($im)) { imagepalettetotruecolor($im); }
    ob_start();
    imagejpeg($im, null, 88);
    $jpg = ob_get_clean();
    imagedestroy($im);
    return 'data:image/jpeg;base64,' . base64_encode($jpg);
}

function gd_grayscale($im) { imagefilter($im, IMG_FILTER_GRAYSCALE); return $im; }
function gd_sepia($im) {
    imagefilter($im, IMG_FILTER_GRAYSCALE);
    imagefilter($im, IMG_FILTER_BRIGHTNESS, -20);
    imagefilter($im, IMG_FILTER_COLORIZE, 90, 60, 30);
    return $im;
}
function gd_invert($im) { imagefilter($im, IMG_FILTER_NEGATE); return $im; }
function gd_rotate90($im) { $r = imagerotate($im, -90, 0); return $r ? $r : $im; }
function gd_rotate180($im) { $r = imagerotate($im, 180, 0); return $r ? $r : $im; }
function gd_fliph($im) { imageflip($im, IMG_FLIP_HORIZONTAL); return $im; }
function gd_flipv($im) { imageflip($im, IMG_FLIP_VERTICAL); return $im; }
function gd_brighten($im) { imagefilter($im, IMG_FILTER_BRIGHTNESS, 35); return $im; }
function gd_darken($im) { imagefilter($im, IMG_FILTER_BRIGHTNESS, -35); return $im; }
function gd_contrast($im) { imagefilter($im, IMG_FILTER_CONTRAST, -20); return $im; }
function gd_sharpen($im) {
    $m = array(array(0.0, -1.0, 0.0), array(-1.0, 5.0, -1.0), array(0.0, -1.0, 0.0));
    imageconvolution($im, $m, 1.0, 0.0);
    return $im;
}
function gd_blur($im) {
    for ($i = 0; $i < 3; $i++) { imagefilter($im, IMG_FILTER_GAUSSIAN_BLUR); }
    return $im;
}
function gd_crop($im) {
    $w = imagesx($im); $h = imagesy($im);
    $s = min($w, $h);
    $r = imagecrop($im, array('x' => (int) (($w - $s) / 2), 'y' => (int) (($h - $s) / 2), 'width' => $s, 'height' => $s));
    return $r ? $r : $im;
}

$EDIT_OPS = array(
    'grayscale' => 'gd_grayscale', 'sepia' => 'gd_sepia', 'invert' => 'gd_invert',
    'rotate90' => 'gd_rotate90', 'rotate180' => 'gd_rotate180',
    'flipH' => 'gd_fliph', 'flipV' => 'gd_flipv',
    'brighten' => 'gd_brighten', 'darken' => 'gd_darken',
    'contrast' => 'gd_contrast', 'sharpen' => 'gd_sharpen',
    'blur' => 'gd_blur', 'crop' => 'gd_crop',
);

function api_edit($payload) {
    global $HAS_GD, $EDIT_OPS;
    if (!$HAS_GD) { throw new Exception('کتابخانه‌ی GD روی هاست فعال نیست'); }
    $raw = parse_dataurl(isset($payload['image']) ? $payload['image'] : '');
    $im = @imagecreatefromstring($raw);
    if (!$im) { throw new Exception('تصویر قابل خواندن نیست'); }
    imagepalettetotruecolor($im);
    if (!imageistruecolor($im)) { $tc = imagecreatetruecolor(imagesx($im), imagesy($im)); imagecopy($tc, $im, 0, 0, 0, 0, imagesx($im), imagesy($im)); $im = $tc; }
    $ops = isset($payload['ops']) ? $payload['ops'] : array();
    if (!is_array($ops)) { $ops = array($ops); }
    $applied = array();
    foreach (array_slice($ops, 0, 6) as $op) {
        $op = (string) $op;
        if (isset($EDIT_OPS[$op])) {
            $im = call_user_func($EDIT_OPS[$op], $im);
            $applied[] = $op;
        }
    }
    if (!count($applied)) { throw new Exception('هیچ عملیاتی شناخته نشد'); }
    ob_start();
    imagejpeg($im, null, 90);
    $jpg = ob_get_clean();
    imagedestroy($im);
    return array('image' => 'data:image/jpeg;base64,' . base64_encode($jpg), 'applied' => $applied);
}

function tavily_search($query) {
    global $TAVILY_KEY;
    $raw = http_json('https://api.tavily.com/search',
        array('query' => $query, 'max_results' => 5, 'search_depth' => 'basic'),
        array('Authorization: Bearer ' . $TAVILY_KEY), 20);
    $j = json_decode($raw, true);
    $out = array();
    if (isset($j['results']) && is_array($j['results'])) {
        foreach ($j['results'] as $r) {
            if (!empty($r['content']) && !empty($r['url'])) {
                $host = parse_url($r['url'], PHP_URL_HOST) ?: 'وب';
                $out[] = array(
                    'title' => !empty($r['title']) ? $r['title'] : $host,
                    'text' => mb_substr($r['content'], 0, 1500),
                    'url' => $r['url'],
                    'label' => str_replace('www.', '', $host),
                );
            }
        }
    }
    return $out;
}

/* ---------------------------------------------------------------- مسیریابی */
if ($OP === 'models') {
    $models = array(array('id' => 'auto', 'label' => 'خودکار (بهترین موتور موجود)'));
    foreach ($ENABLED as $p) { $models[] = array('id' => $p['id'], 'label' => $p['label']); }
    $models[] = array('id' => 'openai-fast', 'label' => 'موتور بدون کلید (ناپایدار)');
    out_json(200, array('models' => $models, 'features' => array(
        'web_search' => (bool) $TAVILY_KEY,
        'polish' => true,
        'vision' => (bool) provider_by_id('groq'),
        'image_gen' => true,
        'image_edit' => $HAS_GD,
    )));
}

if (!rate_limited()) {
    $payload = read_payload();
    if ($ACCESS_KEY === '' || (isset($_SERVER['HTTP_X_ANSAL_KEY']) && $_SERVER['HTTP_X_ANSAL_KEY'] === $ACCESS_KEY)) {

        if ($OP === 'search') {
            if (!$TAVILY_KEY) { out_json(200, array('results' => array())); }
            try {
                out_json(200, array('results' => tavily_search(mb_substr((string) (isset($payload['query']) ? $payload['query'] : ''), 0, 300))));
            } catch (Exception $e) { out_json(200, array('results' => array())); }
        }

        if ($OP === 'image') {
            try { out_json(200, array('image' => api_image($payload))); }
            catch (Exception $e) { out_json(502, array('error' => 'تولید تصویر انجام نشد: ' . mb_substr($e->getMessage(), 0, 120))); }
        }

        if ($OP === 'vision') {
            try { out_json(200, array('text' => api_vision($payload))); }
            catch (Exception $e) { out_json(502, array('error' => 'تحلیل تصویر انجام نشد: ' . mb_substr($e->getMessage(), 0, 120))); }
        }

        if ($OP === 'edit') {
            try { out_json(200, api_edit($payload)); }
            catch (Exception $e) { out_json(502, array('error' => 'ویرایش تصویر انجام نشد: ' . mb_substr($e->getMessage(), 0, 120))); }
        }

        if ($OP === 'chat') {
            $messages = clean_messages(isset($payload['messages']) ? $payload['messages'] : null);
            if (!count($messages)) { out_json(400, array('error' => 'پیام خالی است.')); }
            try {
                list($text, $label) = ask($messages, (string) (isset($payload['model']) ? $payload['model'] : 'auto'), 0.4);
                if (!empty($payload['polish']) && $label !== 'موتور بدون کلید') { $text = polish($text); }
                out_json(200, array('text' => $text, 'label' => $label));
            } catch (Exception $e) {
                $hint = count($ENABLED) ? '' : ' (هنوز هیچ کلیدی در config.json نگذاشته‌ای.)';
                out_json(502, array('error' => 'هیچ‌کدام از موتورها پاسخ نداد.' . $hint));
            }
        }
    } else {
        out_json(401, array('error' => 'این انصال با کلید دسترسی قفل شده است.'));
    }
} else {
    out_json(429, array('error' => 'درخواست‌ها زیاد است؛ یک دقیقه صبر کن.'));
}
